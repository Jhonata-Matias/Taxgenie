# Taxgenie

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jhonata-Matias/pen/dyByymZ](https://codepen.io/Jhonata-Matias/pen/dyByymZ).

Página do sistema de planejamento tributário